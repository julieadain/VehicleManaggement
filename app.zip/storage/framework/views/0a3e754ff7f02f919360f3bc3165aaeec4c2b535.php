<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h3>
            Vehicle Assign
        </h3>

    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-5 pull-left">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                    <table class="table">
                        <caption></caption>
                        <thead>

                        <tr>
                            <th scope="row">Client Name:</th>
                            <td><?php echo e($reservationList->clients-> name); ?></td>
                        </tr>

                        <tr>
                            <th scope="row">Start Date Time:</th>
                            <td><?php echo e($reservationList-> start_date_time); ?></td>
                        </tr>

                        <tr>
                            <th scope="row">End Date Time:</th>
                            <td><?php echo e($reservationList-> end_date_time); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Seat Capacity:</th>
                            <td><?php echo e($reservationList->seat_capacity); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">AC/Non AC:</th>
                            <td><?php if($reservationList->ac == 1): ?>
                                    <?php echo e('AC'); ?>

                                <?php else: ?>
                                    <?php echo e("Non AC"); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Share:</th>
                            <td><?php if($reservationList->share == 1): ?>
                                    <?php echo e('Yes'); ?>

                                <?php else: ?>
                                    <?php echo e("No"); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Pickup Address:</th>
                            <td><?php echo e($reservationList->pickup_address); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Location:</th>
                            <td><?php echo e($reservationList->location); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Start Meter Reading:</th>
                            <td><?php echo e($reservationList-> start_meter_reading); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">End Meter Reading:</th>
                            <td><?php echo e($reservationList->end_meter_reading); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Total Payable:</th>
                            <td><?php echo e($reservationList->total_payable); ?></td>
                        </tr>
                        </thead>
                    </table>
            </div>
        </div>
        <div class="col-md-7 pull-right">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                <table class="table">
                     <h3>Vehicle</h3>
                    <thead>
                    <tr>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td><a href=<?php echo e(url('/vehicleAssign/'. $vehicle->id)); ?>> <?php echo e($vehicle->brand); ?> </a></td>




















                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </thead>


                </table>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/reservation/reservation-detail.blade.php ENDPATH**/ ?>