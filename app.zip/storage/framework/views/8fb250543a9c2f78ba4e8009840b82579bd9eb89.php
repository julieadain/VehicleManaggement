    

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <h3 class="container">
            Vehicle Profile
        </h3>
        <div class="container">
            <div class="col-md-7 pull-left">


            <!-- Horizontal Form -->
                <div class=" container box box-success">

                    <!-- /.box-header -->
                    <!-- form start -->


                    <table class="table">

                        <tbody>
                        <tr>
                            <th scope="row">Brand:</th>
                            <td><?php echo e($vehicle->brand); ?></td>
                        </tr>

                        <tr>
                            <th scope="row">Model:</th>
                            <td><?php echo e($vehicle->model); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Color:</th>
                            <td><?php echo e($vehicle->color); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Reg Number:</th>
                            <td><?php echo e($vehicle->reg_number); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Reg Date:</th>
                            <td><?php echo e($vehicle-> reg_date); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Seat Capacity:</th>
                            <td><?php echo e($vehicle->seat_capacity); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Owner:</th>
                            <td>
                                <?php if($vehicle->ownership_status == 1): ?>
                                    <?php echo e("Yes"); ?>

                                <?php else: ?>
                                    <?php echo e("No"); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">AC:</th>
                            <td>
                                <?php if($vehicle->ac == 1): ?>
                                    <?php echo e("Yes"); ?>

                                <?php else: ?>
                                    <?php echo e("No"); ?>


                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Registration Scan Copy:</th>
                            <td><a href="<?php echo e(asset('upload').'/'.$vehicle->reg_scan_copy); ?>" target="_blank"><?php echo e($vehicle->reg_scan_copy); ?></a>

                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Insurance Scan Copy:</th>
                            <td><a href="<?php echo e(asset('upload').'/'.$vehicle->insurance_scan_copy); ?>" target="_blank"><?php echo e($vehicle->insurance_scan_copy); ?></a>

                            </td>
                        </tr>
                        <tr>
                            <th scope="row">RoadPermit Scan Copy:</th>
                            <td><a href="<?php echo e(asset('upload').'/'.$vehicle->insurance_scan_copy); ?>" target="_blank"><?php echo e($vehicle->roadPermit_scan_copy); ?></a>

                            </td>
                        </tr>


                        </tbody>
                    </table>
                </div>
            </div>
            <div class=" col-md-5 pull-right ">
                <div class="card">
                    <img src="<?php echo e(asset('upload').'/'.$vehicle->photo); ?>" alt="image" style="width: 32rem;">

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/vehicle/single-list.blade.php ENDPATH**/ ?>