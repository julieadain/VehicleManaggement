<?php $__env->startSection('content'); ?>
       <!-- Main content -->
    <section class="content">

        <div class="col-md-7 pull-left">
            <!-- Horizontal Form -->
            <div class=" container box box-success">
                <h4>
                    Sms Log
                </h4>
                    <div class="box">
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example1" class="table  table-striped">
                                <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Details</th>
                                    <th>to.</th>
                                </tr>
                                </thead>
                                <tbody>
                                
                                <tr>
                                    
                                    
                                    
                                    
                                </tr>

                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->


                </div>
            </div>
        </div>

        <div class="col-xs-5">
            <div class="container box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Sms Configuration</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body box-responsive ">
                    <form method="POST" action="<?php echo e(url('#')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="id"
                                   class="col-md-4 col-form-label text-md-right"><?php echo e(__('Id')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email"
                                       class="form-control <?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="id"
                                       value="<?php echo e(old('id')); ?>" required autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password"
                                   class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password"
                                       class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                       required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="text-danger"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/massage.blade.php ENDPATH**/ ?>