<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="row">
            <!-- /.col -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h2 class="box-title">Vehicle List </h2>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table id="vehicle_datatable" class="table table-hover">
                            <thead>
                            <tr>
                                <th class="bg-primary">Brand</th>
                                <th class="bg-primary">Model</th>
                                <th class="bg-primary">Color</th>
                                <th class="bg-primary">Seat Capacity</th>
                                <th class="bg-primary">AC/Non AC</th>

                                <th class="bg-primary">Registration Number</th>
                                <th class="bg-primary">Option</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($vehicle-> brand); ?></td>
                                <td> <?php echo e($vehicle->model); ?></td>
                                <td><?php echo e($vehicle->color); ?></td>
                                <td><?php echo e($vehicle->seat_capacity); ?></td>
                                <td>
                                    <?php if($vehicle->ac == 1): ?>
                                        <?php echo e("AC"); ?>

                                    <?php else: ?>
                                        <?php echo e("Non AC"); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($vehicle->reg_number); ?></td>
                                <td>
                                    <a title="" href="<?php echo e(url("vehicle/$vehicle->id")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-eye"></i></a>
                                    <a title="" href="<?php echo e(url("vehicle/$vehicle->id/edit")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-pencil"></i></a>
                                    <form action="<?php echo e(url("vehicle/$vehicle->id")); ?>" method="post" style="float: left; margin-right: 2px">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure')"><i class="fa fa-trash-o"></i></button>
                                    </form>
                                </td>
                            </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix" style="margin-right:50px;">

                        <ul class="pagination pagination-sm no-margin pull-right">
                            <?php echo e($vehicles->links()); ?>

                        </ul>
                    </div>


                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("page-js"); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $('#vehicle_datatable').DataTable({
            'paging': false,
            'lengthChange': false,
            'searching': true,
            'ordering': false,
            'info': false,
            'autoWidth': false
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/vehicle/detail.blade.php ENDPATH**/ ?>