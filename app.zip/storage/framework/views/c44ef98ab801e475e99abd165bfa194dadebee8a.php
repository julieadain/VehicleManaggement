<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h3>
            Driver Assign
        </h3>

    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-5 pull-left">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                    <table class="table">
                        <caption></caption>
                        <thead>

                        <tr>
                            <th scope="row">Client Name:</th>
                            <td><?php echo e($reservation->clients-> name); ?></td>
                        </tr>


                        <tr>
                            <th scope="row">Start Date Time:</th>
                            <td><?php echo e($reservation-> start_date_time); ?></td>
                        </tr>

                        <tr>
                            <th scope="row">End Date Time:</th>
                            <td><?php echo e($reservation-> end_date_time); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Vehicle</th>
                            <td><?php echo e($reservation->vehicle_id); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Seat Capacity:</th>
                            <td><?php echo e($reservation->seat_capacity); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">AC:</th>
                            <td><?php echo e($reservation->ac); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Share:</th>
                            <td><?php echo e($reservation-> share); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Pickup Address:</th>
                            <td><?php echo e($reservation->pickup_address); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Location:</th>
                            <td><?php echo e($reservation->location); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Start Meter Reading:</th>
                            <td><?php echo e($reservation-> start_meter_reading); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">End Meter Reading:</th>
                            <td><?php echo e($reservation->end_meter_reading); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Total Payable:</th>
                            <td><?php echo e($reservation->total_payable); ?></td>
                        </tr>
                        </thead>
                    </table>
            </div>
        </div>
        <div class="col-md-7 pull-right">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                     <h3>Driver</h3>
                <table class="table">

                <tbody>
                    <tr>
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td>
                                <a href=<?php echo e(url('/driverAssign/'. $driver->id)); ?>> <?php echo e($driver->name); ?></a>
                                <?php $__currentLoopData = $driver->reservations->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <br/>
                                    <?php echo e(date("dM y"), strtotime( $reservation->start_date_time)); ?>

                                    at<?php echo e(date("h:m a"), strtotime( $reservation->start_date_time)); ?>

                                    to  <?php echo e(date("dM y"), strtotime( $reservation->end_date_time)); ?>

                                    at <?php echo e(date("h:m a"), strtotime($reservation->end_date_time)); ?>



                                    <small class="location" > <i class="fa fa-map-marker"> </i><?php echo e($reservation-> location); ?> </small>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>



                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

                    </tbody>


                </table>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/reservation/driver-assign.blade.php ENDPATH**/ ?>