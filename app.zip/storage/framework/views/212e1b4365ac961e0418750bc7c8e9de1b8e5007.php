<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h3>
            Vehicle Assign
        </h3>

    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-5 pull-left">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                <table class="table">
                    <caption></caption>
                    <thead>

                    <tr>
                        <th scope="row">Client Name:</th>
                        <td><?php echo e($reservation->clients-> name); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Start Date Time:</th>
                        <td><?php echo e($reservation-> start_date_time); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">End Date Time:</th>
                        <td><?php echo e($reservation-> end_date_time); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Seat Capacity:</th>
                        <td><?php echo e($reservation->seat_capacity); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">AC/Non AC:</th>
                        <td><?php if($reservation->ac == 1): ?>
                                <?php echo e('AC'); ?>

                            <?php else: ?>
                                <?php echo e("Non AC"); ?>


                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Share:</th>
                        <td><?php if($reservation->share == 1): ?>
                                <?php echo e('Yes'); ?>

                            <?php else: ?>
                                <?php echo e("No"); ?>


                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Pickup Address:</th>
                        <td><?php echo e($reservation->pickup_address); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Location:</th>
                        <td><?php echo e($reservation->location); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Start Meter Reading:</th>
                        <td><?php echo e($reservation-> start_meter_reading); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">End Meter Reading:</th>
                        <td><?php echo e($reservation->end_meter_reading); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Total Payable:</th>
                        <td><?php echo e($reservation->total_payable); ?></td>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="col-md-7 pull-right">
            <!-- Horizontal Form -->
            <div class="box box-info">

                <!-- /.box-header -->
                <!-- form start -->


                <h3>Vehicle</h3>
                <table class="table">
                    <tbody>









































                    <tr>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td>
                                 <a href=<?php echo e(url('/vehicleAssign/'. $vehicle->id)); ?>> <i class="fa fa-car"></i> <?php echo e($vehicle->brand); ?></a>

                                <?php $__currentLoopData = $vehicle->reservations->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <br/>


                                    <?php echo e(date("dM y,", strtotime( $reservation->start_date_time))); ?>

                                    at<?php echo e(date(" h:ia", strtotime( $reservation->start_date_time))); ?>

                                    to  <?php echo e(date("dM y,", strtotime( $reservation->end_date_time))); ?>

                                    at<?php echo e(date(" h:ia", strtotime( $reservation->end_date_time))); ?>



                                    <small class="location" > <i class="fa fa-map-marker"> </i><?php echo e($reservation-> location); ?> </small>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </td>



                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>


                </table>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/reservation/vehicle-assign.blade.php ENDPATH**/ ?>