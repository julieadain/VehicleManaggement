<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Dashboard
            <small>Control panel</small>
        </h1>
        
    </section>
    <!-- Main content -->
    <section class="content">

    <?php echo $__env->make('partials/_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <?php if(auth()->user()->role == 1) { ?>
                        <h3><?php echo e(\App\Vehicle::whereOrg_id(session()->get('org_info')->id)->count()); ?></h3>
                        <?php } ?>
                        <?php if(auth()->user()->role == 2) { ?>
                        <h3><?php echo e(\App\Vehicle::whereOrg_id(Auth::user()->org_id)->count()); ?></h3>
                        <?php } ?>

                        <p>Vehicles</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-android-car"></i>
                    </div>
                    <a href="<?php echo e(url("vehicle")); ?>" class="small-box-footer">More info <i
                                class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <?php if(auth()->user()->role == 1) { ?>
                        <h3><?php echo e(\App\Driver::whereOrg_id(session()->get('org_info')->id)->count()); ?></h3>
                        <?php } ?>
                        <?php if(auth()->user()->role == 2) { ?>
                        <h3><?php echo e(\App\Driver::whereOrg_id(\Illuminate\Support\Facades\Auth::user()->org_id)->count()); ?></h3>
                        <?php } ?>

                        <p>Drivers</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="<?php echo e(url("driver")); ?>" class="small-box-footer">More info <i
                                class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <?php if(auth()->user()->role == 1) { ?>
                        <h3><?php echo e(\App\Reservation::where('status','!=',2)->count()); ?></h3>
                        <?php } ?>
                        <?php if(auth()->user()->role == 2) { ?>
                        <h3><?php echo e(\App\Reservation::where('status','!=',2)->count()); ?></h3>
                        <?php } ?>

                        <p>Booking</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-android-checkbox"></i>
                    </div>
                    <a href="<?php echo e('currentReservation'); ?>" class="small-box-footer">More info <i
                                class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>9238</h3>
                        
                        <p>SMS</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-android-mail"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->

        <div class="row">
            <!-- Left col -->
            <section class="col-lg-7 connectedSortable">
                <!-- Custom tabs (Charts with tabs)-->
                <div class="box box-primary">
                    <div class="box-header">
                        <i class="ion ion-clipboard"></i>

                        <h3 class="box-title">Reservation</h3>
                        <div class="box-tools pull-right">
                            <button class="btn btn-default" style="margin-right: 5px;"><a
                                        href="<?php echo e(url("currentReservation")); ?>"> <i class="fa fa-file"></i> </a></button>

                            <button type="button" class="btn btn-default pull-right"><a href="<?php echo e(url('client')); ?>"> <i
                                            class="fa fa-plus"></i></a></button>
                        </div>

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
                        <ul class="todo-list">

                            <div class="box-body table-responsive no-padding">
                                <table class="table table-hover">
                                    <tr class="lovelyrow">

                                    </tr>
                                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="lovelyrow"
                                            onclick="location.href='<?php echo e($reservation->id); ?>/currentReservation'">

                                            <td><b><?php echo e($reservation->clients->name); ?></b></td>
                                            <td><?php echo e(date("dM y,", strtotime( $reservation->start_date_time))); ?>

                                                at<?php echo e(date(" h:ia", strtotime( $reservation->start_date_time))); ?>

                                                to <?php echo e(date("dM y,", strtotime( $reservation->end_date_time))); ?>

                                                at<?php echo e(date(" h:ia", strtotime( $reservation->start_date_time))); ?></td>
                                            <td><i class="fa fa-map-marker"> </i>
                                                <small><?php echo e($reservation-> location); ?> </small>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>

                <div class="box box-primary">
                    <div class="box-header">
                        <i class="ion ion-clipboard"></i>

                        <h3 class="box-title">Recent Clients</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-default pull-right"><a href="<?php echo e(url('client/create')); ?>">
                                    <i class="fa fa-plus"> </i> </a></button>
                        </div>

                    </div>
                    <div class="box-body">
                        <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
                        <ul class="todo-list">


                            <div class="box-body table-responsive no-padding">
                                <table class="table table-hover">
                                    <tr class="lovelyrow">

                                    </tr>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="lovelyrow" onclick="location.href='client'">

                                            <td><b><?php echo e($client-> name); ?></b></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </ul>
                    </div>
                </div>
            </section>
            <!-- /.Left col -->
            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-5 connectedSortable">

                <!-- Map box -->
                <div class="box box-primary">
                    <div class="nav-tabs-custom">
                        <div class="box-header">
                            <i class="ion ion-clipboard"></i>

                            <h3 class="box-title">Available Vehicles</h3>

                        </div>
                        <div class="box-body">
                            <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
                            <ul class="todo-list">

                                <div class="box-body table-responsive no-padding">
                                    <table class="table table-hover">
                                        <tr class="lovelyrow">

                                        </tr>
                                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="lovelyrow"
                                                onclick="location.href='dashboard/vehicle/<?php echo e($vehicle->id); ?>'">

                                                <td style="color: #0b58a2"><b><?php echo e($vehicle->brand); ?></b></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /.box -->

                <!-- solid sales graph -->
                <div class="box box-primary">
                    <div class="box box-solid bg-light-blue-gradient">
                        <div class="nav-tabs-custom">
                            <div class="box-header">
                                <i class="ion ion-clipboard"></i>

                                <h3 class="box-title">Available Drivers</h3>

                            </div>
                            <div class="box-body">
                                <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
                                <ul class="todo-list">


                                    <div class="box-body table-responsive no-padding">
                                        <table class="table table-hover">
                                            <tr class="lovelyrow">

                                            </tr>
                                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="lovelyrow"
                                                    onclick="location.href='dashboard/driver/<?php echo e($driver->id); ?>'">

                                                    <td style="color: #0b58a2"><b><?php echo e($driver->name); ?></b></td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>


                                    

                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    

                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /.box -->
                </div>
            </section>
            <!-- right col -->
        </div>
        <!-- /.row (main row) -->

    </section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/dashboard.blade.php ENDPATH**/ ?>