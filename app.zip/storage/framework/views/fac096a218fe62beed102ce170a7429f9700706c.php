<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="col-md-6 connectedSortable pull-left" style="padding-top: 10px;">
            <!-- Profile Image -->
            <div class="box box-primary">
                <form method="POST" action="<?php echo e(url('storeAddress')); ?>"
                      style="padding: 10px;">
                    <?php echo csrf_field(); ?>
                    <ul class="list-group" style="padding-top: 10px;">
                        <b><?php echo e("Current Address :"); ?></b>
                        <li class="list-group-item"><?php echo e(\Illuminate\Support\Facades\Auth::User()->organization->address); ?> </li>
                    </ul>
                    <div class="form-group">
                        <label for="exampleInputAddress">New Address</label>
                        <input type="text" class="form-control" name="address" id="exampleInputAddress" aria-describedby="addressHelp" placeholder="Enter new address">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Enter Password</label>
                        <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
                        <?php if(session('errorPass')): ?>
                            <h5 class="text-danger pull-right"><?php echo e(session('errorPass')); ?></h5>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </section>
        <section class="col-md-6 connectedSortable pull-right" style="padding-top: 10px;">
            <!-- Profile Image -->
            <div class="box no-border">
                <div class="box-body ">
                    <ul class="list-group">
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changeLogo')); ?>">Change profile Logo</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changePhone')); ?>">Change Phone</a>
                        </li>
                        <li class="list-group-item no-border ">
                            <a href="<?php echo e(url('changeEmail')); ?>">Change Email</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changeAddress')); ?>">Change Address</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changePassword')); ?>">Change Password</a>
                        </li>

                    </ul>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/profile/change_address.blade.php ENDPATH**/ ?>