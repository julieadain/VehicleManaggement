<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h3 >
            Reservation History
        </h3>

    </section>


    <!-- Main content -->
    <section class="container">

        <!-- /.col -->
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-11">
                <div class="box">

                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tr>
                                <th class="bg-primary"> Client Name</th>
                                <th class="bg-primary">Start Date Time</th>
                                <th class="bg-primary">end_date_time</th>
                                <th class="bg-primary">Seat Capacity  </th>
                                <th class="bg-primary">AC/Non AC </th>
                                <th class="bg-primary">Owner </th>
                                <th class="bg-primary">Driver </th>
                            </tr>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($reservation->client-> name); ?></td>
                                    <td><?php echo e(date("d M y,", strtotime( $reservation->start_date_time))); ?>

                                        at<?php echo e(date(" h:ia", strtotime( $reservation->start_date_time))); ?></td>
                                    <td><?php echo e(date("d M y,", strtotime( $reservation->end_date_time))); ?>

                                        at<?php echo e(date(" h:ia", strtotime( $reservation->end_date_time))); ?></td>
                                    <td><?php echo e($reservation->seat_capacity); ?></td>
                                    <td>
                                        <?php if($reservation->ac == 1): ?>
                                            <?php echo e("Yes"); ?>

                                        <?php else: ?>
                                            <?php echo e("No"); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($reservation->share == 1): ?>
                                            <?php echo e("Yes"); ?>

                                        <?php else: ?>
                                            <?php echo e("No"); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($reservation->driver->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>






<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/reservation/reservation-history.blade.php ENDPATH**/ ?>