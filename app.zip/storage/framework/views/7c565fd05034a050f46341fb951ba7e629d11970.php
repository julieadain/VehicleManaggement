<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="col-md-6 connectedSortable pull-left" style="padding-top: 10px;">
                           <!-- Profile Image -->
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img class="profile-user-img img-responsive img-circle"
                             src="<?php echo e(asset('upload').'/'.$organization->logo); ?>" alt="User profile picture">

                        <h3 class="profile-username text-center"><?php echo e($organization->org_name); ?></h3>

                        <p class="text-muted text-center"><?php echo e("Member since - " . date('d M Y', strtotime($organization->created_at))); ?></p>

                        <ul class="list-group">
                            <li class="list-group-item">
                                <b>Owner : </b><?php echo e($organization->owner->name); ?>

                            </li>
                            <li class="list-group-item">
                                <b>Address : </b><?php echo e($organization->address); ?>

                            </li>
                            <li class="list-group-item">
                                <b>Email : </b><?php echo e($organization->owner->email); ?>

                            </li>
                            <li class="list-group-item">
                                <b>Phone : </b><?php echo e($organization->owner->phone); ?>

                            </li>
                            <li class="list-group-item">
                                <b>Trade license : </b>
                                <td><a href="<?php echo e(asset('upload').'/'.$organization->trade_license_copy); ?>"
                                       target="_blank"><?php echo e($organization->trade_license_copy); ?></a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
        </section>
        <section class="col-md-6 connectedSortable pull-right" style="padding-top: 10px;">
                            <!-- Profile Image -->
                <div class="box no-border">
                    <div class="box-body ">
                        <ul class="list-group">
                            <li class="list-group-item no-border">
                                <a href="<?php echo e(url('changeLogo')); ?>">Change profile Logo</a>
                            </li>
                            <li class="list-group-item no-border">
                                <a href="<?php echo e(url('changePhone')); ?>">Change Phone</a>
                            </li>
                            <li class="list-group-item no-border ">
                                <a href="<?php echo e(url('changeEmail')); ?>">Change Email</a>
                            </li>
                            <li class="list-group-item no-border">
                                <a href="<?php echo e(url('changeAddress')); ?>">Change Address</a>
                            </li>
                            <li class="list-group-item no-border">
                                <a href="<?php echo e(url('changePassword')); ?>">Change Password</a>
                            </li>

                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
        </section>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/profile/view.blade.php ENDPATH**/ ?>