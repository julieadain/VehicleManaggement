<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="col-md-6 connectedSortable pull-left" style="padding-top: 10px;">
            <!-- Profile Image -->
            <div class="box box-primary">
                <?php if($errors->any()): ?>
                    <div class="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(url('storePhone')); ?>" enctype="multipart/form-data"
                      style="padding: 10px;">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputPhone1">Present Phone</label>
                        <input type=tel class="form-control" name="phone" id="exampleInputPhone1"  placeholder="Enter current phone">
                        <?php if(session('errorPhone')): ?>
                            <h5 class="text-danger pull-right"><?php echo e(session('errorPhone')); ?></h5>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPhone">New Phone</label>
                        <input type=tel class="form-control" name="newPhone" id="exampleInputPhone"  aria-describedby="addressHelp" placeholder="Enter new phone">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Enter Password</label>
                        <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
                        <?php if(session('errorPass')): ?>
                            <h5 class="text-danger pull-right"><?php echo e(session('errorPass')); ?></h5>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </section>
        <section class="col-md-6 connectedSortable pull-right" style="padding-top: 10px;">
            <!-- Profile Image -->
            <div class="box no-border">
                <div class="box-body ">
                    <ul class="list-group">
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changeLogo')); ?>">Change profile Logo</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changePhone')); ?>">Change Phone</a>
                        </li>
                        <li class="list-group-item no-border ">
                            <a href="<?php echo e(url('changeEmail')); ?>">Change Email</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changeAddress')); ?>">Change Address</a>
                        </li>
                        <li class="list-group-item no-border">
                            <a href="<?php echo e(url('changePassword')); ?>">Change Password</a>
                        </li>

                    </ul>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/profile/change_phone.blade.php ENDPATH**/ ?>