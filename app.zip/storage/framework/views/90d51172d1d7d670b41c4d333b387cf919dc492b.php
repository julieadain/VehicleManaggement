<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="col-xs-7">
            <div class="container box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Organizations |
                        <span class="label label-primary pull-right"><?php echo e($organizations->count()); ?></span>
                    </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table id="org_datatable" class="table table-hover">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Owner</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="lovelyrow" onclick="location.href='organization/<?php echo e($organization->id); ?>'">
                                <td><?php echo e($organization->org_name); ?></td>
                                <td><?php echo e($organization->owner ? $organization->owner->name : null); ?></td>
                                <td><?php echo e($organization->owner ? $organization->owner->email : null); ?></td>
                                <td><span class="label label-success">Approved</span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="box-footer clearfix" style="margin-right:50px;">

                        <ul class="pagination pagination-sm no-margin pull-right">
                            <?php echo e($organizations->links()); ?>


                        </ul>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>

        <div class="col-xs-5">
            <div class="container box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Requests |
                        <span class="label label-warning pull-right"><?php echo e($requests->count()); ?></span>
                    </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover ">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Owner</th>
                            <th>Email</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="lovelyrow" onclick="location.href='organization/<?php echo e($request->id); ?>'">
                                <td><?php echo e($request->org_name); ?></td>
                                <td><?php echo e($request->owner ? $request->owner->name : null ?? ''); ?></td>
                                <td><?php echo e($request->owner ? $request->owner->email : null  ?? ''); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <div class="col-xs-5 pull-right">
            <div class="container box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Denied |
                        <span class="label label-danger pull-right"><?php echo e($denials->count()); ?></span>
                    </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover ">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Owner</th>
                            <th>Email</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $denials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="lovelyrow">
                                
                                <td><?php echo e($denial->org_name); ?></td>
                                <td><?php echo e($denial->owner ? $denial->owner->name : null); ?></td>
                                <td><?php echo e($denial->owner ? $denial->owner->email : null); ?></td>
                                <td><a class="btn btn-success" href="<?php echo e(url('/approve/'. $denial->id)); ?>">Approve</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>




                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush("page-js"); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $('#org_datatable').DataTable({
            'paging': false,
            'lengthChange': false,
            'searching': true,
            'ordering': false,
            'info': false,
            'autoWidth': false
        })
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/organization/view.blade.php ENDPATH**/ ?>