<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="row">

        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h2 class="box-title">Payments Due</h2>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table id="vehicle_datatable" class="table table-hover">
                            <thead>
                            <tr>
                                <th class="bg-primary">Due Date</th>
                                <th class="bg-primary">Package</th>
                                <th class="bg-primary">Client name</th>
                                <th class="bg-primary">Organization</th>
                                <th class="bg-primary">Paid</th>
                                <th class="bg-primary"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($payments->count() == 0): ?>
                                <tr>
                                    <td><h3 class="text-warning"> No request found !</h3></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($payment->date); ?></td>
                                    <td><?php echo e($payment->package? $payment->package->title : null); ?></td>
                                    <td><?php echo e($payment->organization ? $payment->organization->owner->name : null); ?></td>
                                    <td><?php echo e($payment->organization? $payment->organization->org_name : null); ?></td>
                                    <td><?php echo e($payment->paid); ?></td>
                                    <td>
                                        <a class="btn btn-default" href="<?php echo e(url('paymentView/'. $payment->id)); ?>">Make payment</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix" style="margin-right:50px;">

                        <ul class="pagination pagination-sm no-margin pull-right">
                            <?php echo e($payments->links()); ?>

                        </ul>
                    </div>
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/payment/dueList.blade.php ENDPATH**/ ?>