<?php $__env->startSection('content'); ?>



    <section class="content">
        <div class="row">

            <!-- /.col -->

            <!-- /.col -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h2 class="box-title">Driver List </h2>

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table id="driver_datatable" class="table table-hover">
                            <thead>
                            <tr>
                                <th class="bg-primary">Name</th>
                                <th class="bg-primary">Email</th>
                                <th class="bg-primary">Phone</th>
                                <th class="bg-primary">Address</th>

                                <th class="bg-primary">Option</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($driver->name); ?></td>
                                    <td> <?php echo e($driver->email); ?></td>
                                    <td><?php echo e($driver->phone); ?></td>
                                    <td><?php echo e($driver->address); ?></td>

                                    <td>
                                        <a title="" href="<?php echo e(url("driver/$driver->id")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-eye"></i></a>
                                        <a title="" href="<?php echo e(url("driver/$driver->id/edit")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-pencil"></i></a>
                                        <form action="<?php echo e(url("driver/$driver->id")); ?>" method="post" style="float: left; margin-right: 2px">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure')"><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix" style="margin-right:50px;">

                        <ul class="pagination pagination-sm no-margin pull-right">
                            <?php echo e($drivers->links()); ?>


                        </ul>
                    </div>


                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>


<?php $__env->startPush("page-js"); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $('#driver_datatable').DataTable({
            'paging': false,
            'lengthChange': false,
            'searching': true,
            'ordering': false,
            'info': false,
            'autoWidth': false
        })
    </script>

<?php $__env->stopPush(); ?>













<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/driver/detail.blade.php ENDPATH**/ ?>