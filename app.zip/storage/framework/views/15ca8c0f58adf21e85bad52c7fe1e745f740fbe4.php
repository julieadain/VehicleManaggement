<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>