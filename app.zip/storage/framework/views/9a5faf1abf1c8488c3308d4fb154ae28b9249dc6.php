<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h3>
            Client List
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-default" style="margin-right: 45px;"><a
                            href="<?php echo e(url('client/create')); ?>">
                        <i class="fa fa-plus"> </i> </a></button>
            </div>
        </h3>

    </section>


    <!-- Main content -->
    <section class="container">

        <!-- /.col -->
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-11">
                <div class="box">

                    <div class="box-body table-responsive no-padding">
                        <table id="client_datatable" class="table table-hover">
                            <thead>
                            <tr>
                                <th class="bg-primary">Name</th>
                                <th class="bg-primary">Email</th>
                                <th class="bg-primary">Phone</th>
                                <th class="bg-primary"> Address</th>
                                <th class="bg-primary"> Option</th>


                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($client-> name); ?></td>
                                    <td> <?php echo e($client->email); ?> </td>
                                    <td> <?php echo e($client->phone); ?></td>
                                    <td> <?php echo e($client->address); ?></td>

                                    <td>
                                        <div style="width: 200px;">

                                            <a title="rdgrdg" href="<?php echo e(url("client/$client->id/reservation/create")); ?>"
                                               class="btn btn-primary" style="float: left; margin-right: 2px"> Order
                                                now </a>
                                            <a title="rdgrdg" href="<?php echo e(url("client/$client->id/edit")); ?>"
                                               class="btn btn-primary" style="float: left; margin-right: 2px"><i
                                                        class="fa fa-pencil"></i></a>
                                            <form action="<?php echo e(route('client.destroy', $client->id)); ?>" method="post"
                                                  style="float: left; margin-right: 2px">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"
                                                        onclick="return confirm('Are you sure')"><i
                                                            class="fa fa-trash-o"></i></button>
                                            </form>
                                        </div>
                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>


                        </table>
                        <div class="pull-right" style="padding-right: 25px;"><?php echo e($clients->links()); ?></div>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("page-js"); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $('#client_datatable').DataTable({
            'paging': false,
            'lengthChange': false,
            'searching': true,
            'ordering': false,
            'info': false,
            'autoWidth': false
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/client/detail.blade.php ENDPATH**/ ?>