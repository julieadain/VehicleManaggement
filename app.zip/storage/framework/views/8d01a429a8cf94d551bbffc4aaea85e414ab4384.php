<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h3 >
            Reservation List
        </h3>

    </section>


    <!-- Main content -->
    <section class="container">

        <!-- /.col -->
        <!-- /.row -->
        <div class="row">
            <div class="col-xs-11">
                <div class="box">

                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tr>
                                <th class="bg-primary"> Client Name</th>
                                <th class="bg-primary">Start Date Time</th>
                                <th class="bg-primary">end_date_time</th>
                                <th class="bg-primary">Seat Capacity  </th>
                                <th class="bg-primary">AC/Non AC </th>
                                <th class="bg-primary">Owner </th>
                                <th class="bg-primary"> Option </th>




                            </tr>
                            <?php $__currentLoopData = $reservationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($reservation->clients-> name ?? ''); ?></td>
                                    <td><?php echo e(date("dM y,", strtotime( $reservation->start_date_time ?? ''))); ?>

                                        at<?php echo e(date(" h:ia", strtotime( $reservation->start_date_time ?? ''))); ?></td>
                                    <td><?php echo e(date("dM y,", strtotime( $reservation->end_date_time ?? ''))); ?>

                                        at<?php echo e(date(" h:ia", strtotime( $reservation->end_date_time ?? ''))); ?></td>
                                    <td><?php echo e($reservation->seat_capacity ?? ''); ?></td>
                                    <td>
                                        <?php if($reservation->ac == 1): ?>
                                            <?php echo e("Yes"); ?>

                                        <?php else: ?>
                                            <?php echo e("No"); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($reservation->share == 1): ?>
                                            <?php echo e("Yes"); ?>

                                        <?php else: ?>
                                            <?php echo e("no"); ?>


                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a title="rdgrdg" href="<?php echo e(url("reservation/$reservation->id")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-eye"></i></a>
                                        <a title="rdgrdg" href="<?php echo e(url("reservation/$reservation->id/edit")); ?>" class="btn btn-primary" style="float: left; margin-right: 2px"><i class="fa fa-pencil"></i></a>
                                        <form action="<?php echo e(url("reservation/$reservation->id")); ?>" method="post" style="float: left; margin-right: 2px">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure')"><i class="fa fa-trash-o"></i></button>

                                        </form>
                                    </td>




                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </table>
                        
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>






<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/client/reservation-list.blade.php ENDPATH**/ ?>