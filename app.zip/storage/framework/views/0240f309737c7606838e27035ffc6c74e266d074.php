<?php $__env->startSection("content"); ?>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="container box">
                    <div class="box-header">

                        <h4 class="box-title"><?php echo e($organization->org_name); ?>

                            <?php if($organization->status == 1): ?>
                                <span class="label label-primary">Approved</span>
                            <?php else: ?>
                                <span class="label label-warning">Pending</span>
                            <?php endif; ?>
                        </h4>
                        <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 300px;">

                                <?php if($organization->status != 1): ?>
                                    <div class="input-group-btn" style="padding-right: 5px;">
                                         <span class="label label-primary"><a class="btn btn-success text-bold" href="<?php echo e(url('/approve/'. $organization->id)); ?>"> Approve </a></span>
                                    </div>
                                <?php elseif($organization->status !=0): ?>
                                    <div class="input-group-btn" style="padding-right: 5px;">
                                        <span class="label label-primary"><a class="btn btn-success text-bold" href="<?php echo e(url('/details/'. $organization->id)); ?>"> View details </a></span>
                                    </div>
                                    <div class="input-group-btn" style="padding-right: 5px;">
                                        <span class="label label-primary"><a class="btn btn-warning text-bold" href="<?php echo e(url('/pending/'. $organization->id)); ?>"> Pending </a></span>
                                    </div>
                                <?php endif; ?>
                                <div class="input-group-btn" style="padding-right: 5px;">
                                    <span class="label label-primary"><a class="btn btn-danger text-bold" href="<?php echo e(url('/deny/'. $organization->id)); ?>"> Deny </a></span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="box-body table-responsive">
                        <table class="table text-center">
                            <thead>
                            <tr class="hidden">
                                <th scope="col">Id</th>
                                <td><?php echo e($organization->id); ?></td>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row">Address</th>
                                <td><?php echo e($organization->address); ?></td>

                            </tr>
                            <tr>
                                <th scope="row">Owner</th>
                                <td><?php echo e($organization->owner->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td colspan="2"><?php echo e($organization->owner->email); ?>d</td>
                            </tr>
                            <tr>
                                <th scope="row">Phone</th>
                                <td colspan="2"><?php echo e($organization->owner->phone); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Trade license</th>
                                <td colspan="2"><a href="#"><?php echo e($organization->trade_license_copy); ?></a></td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Nairit\work\XAMPP\htdocs\Laravel\Vehicle_Management\vehicle-management\resources\views/organization/detail.blade.php ENDPATH**/ ?>