<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Report;
use Faker\Generator as Faker;

$factory->define(Report::class, function (Faker $faker) {
    return [
        //
    ];
});
