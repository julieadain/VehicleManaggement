<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Manager;
use Faker\Generator as Faker;

$factory->define(Manager::class, function (Faker $faker) {
    return [
        //
    ];
});
